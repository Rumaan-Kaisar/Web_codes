# CSS Distribution

This repository is a fork of semantic-ui-css, with offline fonts.

## Install

```
npm i semantic-ui-offline -S
```

## Update

In dev, you can restart the script with:

```
npm start
```
